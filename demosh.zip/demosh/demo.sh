#!/bin/bash

# Form login
read -p "Username: " username
read -s -p "Password: " password

# Kiểm tra username và password
if [ "$username" == "root" ] && [ "$password" == "root" ]; then
    echo "..............Người dùng hợp lệ.................."
    clear
    echo "welcome to TOOLS thanhnoji"
    sleep 2
    # Cài đặt package
    e="echo -e "
    r='\033[0;31m'
    h='\033[0;32m'
    k='\033[0;33m'
    b='\033[0;34m'
    bl="\033[1;34m"
    purple='\033[0;35m'
    cyan='\033[0;36m'
    p='\033[0;37m'
    bgr='\033[41m'
    bgh='\033[42m'
    bgk='\033[43m'
    bgb='\033[44m'
    bgpurple='\033[45m'
    bgc='\033[46m'
    bgp='\033[47m'
    clear
    play -q robot.mp3 &>/dev/null &
    $e  "        $r installing package...!"
    apt install golang sox -y
    clear
    play -q robot2.mp3 &>/dev/null &
    $e "        $h Installing Package Succes"
    sleep 3
    while true; do
        clear
        $e $h"  ████████╗██╗  ██╗ █████╗ ███╗   ██╗██╗  ██╗    ███╗   ██╗ ██████╗      ██╗██╗"
        $e $h"  ╚══██╔══╝██║  ██║██╔══██╗████╗  ██║██║  ██║    ████╗  ██║██╔═══██╗     ██║██║"
        $e $h"     ██║   ███████║███████║██╔██╗ ██║███████║    ██╔██╗ ██║██║   ██║     ██║██║"
        $e $h"     ██║   ██╔══██║██╔══██║██║╚██╗██║██╔══██║    ██║╚██╗██║██║   ██║██   ██║██║"
        $e $h"     ██║   ██║  ██║██║  ██║██║ ╚████║██║  ██║    ██║ ╚████║╚██████╔╝╚█████╔╝██║"
        $e $h"     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝    ╚═╝  ╚═══╝ ╚═════╝  ╚════╝ ╚═╝"
        echo
        echo
        play -q hello.mp3 &>/dev/null
        play -q robot2.mp3 &>/dev/null &
        $e $bl"        ╔════════════════════════════╗"
        $e $bl"        ║$r Name$cyan :$h thanhoji$bl            ║"
        $e $bl"        ╚════════════════════════════╝"
        $e $bl"        ║                            ║"
        $e $bl"╔═════════════════════════════════════════════╗"
        $e $bl"║ $k 1.$h admin            $k 0.$h out$bl                ║"
        $e $bl"╚═════════════════════════════════════════════╝"
        echo
        $e $bl "┌[$r root $bl]-($h thanhnoji $bl)"
        read -p " └>  " pil
        $e $cyan
        if [ $pil = "1" ]; then
            read -s -p "key admin: " key
            if [ "$key" == "thanhnoji" ]; then
                clear
                play -q robot2.mp3 &>/dev/null &
                $e "        $h ...loading..."
                sleep 3
                play -q klik.mp3 &>/dev/null &
                $e $k
              source startadmin.sh
            else
                echo " password sai."
                 exit 1
           fi
        elif [ $pil = "0" ]; then
            $e $bgh "EMOT BATU"
            exit 1
        else
            $e $p " Tuan ! Input Yang Anda Masukan Salah !"
            sleep 2
            read -p " Enter Untuk Menggulang"
        fi
    done
else
    echo "Username hoặc password sai."
    exit 1
fi
